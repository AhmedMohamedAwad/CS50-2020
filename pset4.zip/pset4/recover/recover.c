#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

typedef uint8_t BYTE;

int main(int argc, char *argv[])
{
    FILE *c = fopen(argv[1], "r");
    if (argc != 2 || c == NULL)
    {
        printf("Usage: ./recover image\n");
        return 1;
    }

    int x = 512;                // Count Byte for End
    int name = 0;            // for ###.jpg

    BYTE *n = malloc(512 * sizeof(BYTE));
    FILE *img = NULL;

    do
    {
        x = fread(n, sizeof(BYTE), 512, c);             // End of File ?!
        if ((name == 49) && (n[0] == 0Xff) && (n[1] == 0xd8) && (n[2] == 0xff) && (((n[3]) & (0xf0)) == 0xe0))
        {

        }
        if ((n[0] == 0Xff) && (n[1] == 0xd8) && (n[2] == 0xff) && (((n[3]) & (0xf0)) == 0xe0))
        {
            if (name != 0)
            {
                fclose(img);
            }

            sprintf(argv[1], "%03i.jpg", name);
            img = fopen(argv[1], "w");
            fwrite(n, sizeof(BYTE), 512, img);
            name ++;
        }
        else if (name != 0)
        {
            fwrite(n, sizeof(BYTE), x, img);
        }
        //int t = ftell(c);
        //printf("%i\n",t);
    }
    while (x == 512);


    fclose(img);
    fclose(c);
    free(n);

    return 0;
}