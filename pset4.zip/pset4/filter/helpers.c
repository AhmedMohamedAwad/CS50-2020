#include "helpers.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>


// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int a = round((image[i][j].rgbtBlue + image[i][j].rgbtRed + image[i][j].rgbtGreen) / 3.0);
            image[i][j].rgbtBlue = a;
            image[i][j].rgbtRed = a;
            image[i][j].rgbtGreen = a;
        }
    }

    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            RGBTRIPLE a;
            a.rgbtRed = 0x0;
            a.rgbtGreen = 0x0;
            a.rgbtBlue = 0x0;

            // sepiaRed = .393 * originalRed + .769 * originalGreen + .189 * originalBlue
            long x = round((0.393 * image[i][j].rgbtRed) + (0.769 * image[i][j].rgbtGreen) + (0.189 * image[i][j].rgbtBlue));
            if (x > 0xff)
            {
                a.rgbtRed = 0xff;
            }
            else if (x < 0)
            {
                a.rgbtRed = 0;
            }
            else
            {
                a.rgbtRed = x;
            }

            //sepiaGreen = .349 * originalRed + .686 * originalGreen + .168 * originalBlue
            long y = round((0.349 * image[i][j].rgbtRed) + (0.686 * image[i][j].rgbtGreen) + (0.168 * image[i][j].rgbtBlue));
            if (y > 0xff)
            {
                a.rgbtGreen = 0xff;
            }
            else if (y < 0)
            {
                a.rgbtGreen = 0;
            }
            else
            {
                a.rgbtGreen = y;
            }

            //sepiaBlue = .272 * originalRed + .534 * originalGreen + .131 * originalBlue
            long z = round((0.272 * image[i][j].rgbtRed) + (0.534 * image[i][j].rgbtGreen) + (0.131 * image[i][j].rgbtBlue));
            if (z > 0xff)
            {
                a.rgbtBlue = 0xff;
            }
            else if (z < 0)
            {
                a.rgbtBlue = 0;
            }
            else
            {
                a.rgbtBlue = z;
            }
            image[i][j].rgbtRed = a.rgbtRed;
            image[i][j].rgbtGreen = a.rgbtGreen;
            image[i][j].rgbtBlue = a.rgbtBlue;
        }
    }

    return;
}
// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{

    for (int i = 0; i < height ; i++)
    {
        int w = width - 1;
        for (int j = 0; j < (width / 2); j++)
        {
            RGBTRIPLE a;
            a = image[i][j];

            image[i][j] = image[i][w];

            image[i][w] = a;

            w --;
        }

    }
    return;
}

typedef struct
{
    long  rgbtBlue;
    long  rgbtGreen;
    long  rgbtRed;
} __attribute__((__packed__))
RGBTRIPLELONG;

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLELONG b[height][width];
    long a = 0;                      // store value of image[i][j].R G B, and add for b. R G B

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            float n = 0.0;              //count for pixles
            b[i][j].rgbtRed = 0;
            b[i][j].rgbtGreen = 0;
            b[i][j].rgbtBlue = 0;

            int r = i - 1;
            int c = j - 1;

            for (int x = 0; x < 3; x ++)
            {
                if (r < 0)
                {
                    r++;
                    x++;
                }
                else if (r == (height - 1))
                {

                    x++;
                }
                for (int z = 0; z < 3; z ++)
                {
                    if (c < 0)
                    {
                        c++;
                        z++;
                    }
                    else if (c == (width - 1))
                    {

                        z++;
                    }

                    a = image[r][c].rgbtRed;
                    b[i][j].rgbtRed += a;
                    a = image[r][c].rgbtGreen;
                    b[i][j].rgbtGreen += a;
                    a = image[r][c].rgbtBlue;
                    b[i][j].rgbtBlue += a;

                    c++;
                    n++;
                }

                c = j - 1;
                r++;
            }
            //printf("%ld\n%ld\n%ld\n",b[i][j].rgbtRed,b[i][j].rgbtGreen,b[i][j].rgbtBlue);
            b[i][j].rgbtRed = round(b[i][j].rgbtRed / n);
            b[i][j].rgbtGreen = round(b[i][j].rgbtGreen / n);
            b[i][j].rgbtBlue = round(b[i][j].rgbtBlue / n);
            //printf("%ld\n%ld\n%ld\n",b[i][j].rgbtRed,b[i][j].rgbtGreen,b[i][j].rgbtBlue);

            //}

        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtRed = b[i][j].rgbtRed;
            image[i][j].rgbtGreen = b[i][j].rgbtGreen;
            image[i][j].rgbtBlue = b[i][j].rgbtBlue;
        }
    }
}