
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

int c_l(string t);
int c_w(string t);
int c_s(string t);
float L, W, S;

int main(void)
{
    string t = get_string("Text: ");
    c_l(t);                           //Counting Letter(s)
    c_w(t);                           //c_w = Counting Word(s)
    c_s(t);                           //c_s = Counting sentence(s)
    printf("%f\n%f\n%f\n", L, W, S);
    float l = (L / W * 100);
    float s = (S / W * 100);
    int index = round(0.0588 * l - 0.296 * s - 15.8);
    printf("%f\n%f\n%i\n", l, s, index);
    if (index <= 1)
    {
        printf("Before Grade 1\n");
    }
    else if (index > 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Grade %i\n", index);
    }

}



int c_l(string t)                     //c_l = Counting Letter(s)
{
    for (int i = 0, n = strlen(t); i < n ; i++)
    {
        if (((t[i] >= 'a') && (t[i] <= 'z')) || ((t[i] >= 'A') && (t[i] <= 'Z')))
        {
            L ++;
        }
    }
    return L;
}

int c_w(string t)                     //c_w = Counting Word(s)
{
    for (int i = 0, n = strlen(t); i < n ; i++)
    {
        if (t[i] <= ' ')
        {
            W ++;
        }
    }
    W++;
    return W;
}

int c_s(string t)                     //c_s = Counting sentence(s)
{
    for (int i = 0, n = strlen(t); i < n ; i++)
    {
        if ((t[i] == '.') || (t[i] == '?') || (t[i] == '!'))
        {
            S ++;
            //printf("%i\n",S);
        }
    }
    return S;
}
