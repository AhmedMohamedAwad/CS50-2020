#include<stdio.h>
#include<cs50.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>


int main(int argc, string argv[])
{

    int c = 0;
    
    if(argc != 2)
    {
           printf("./caesar key\n ");
           return 1;
    }
    int a = atoi(argv[1]);
    for (int j = 0; j < strlen(argv[1]); j++)
    {
        if (isdigit(argv[1][j]))
        {
            c++;
        }
    }

    if ((c != 0) && (c == strlen(argv[1])) && (argc == 2))
    {
        string plaintext = get_string("plaintext: ");
        int n = strlen(plaintext);   //get plaintext from user
        char ci[n];
        for (int i = 0; i < n; i++)
        {
            if ((isupper(plaintext[i])) && (isalpha(plaintext[i])))   //plaintext is upper
            {
                plaintext[i] = plaintext[i] - 65;
                ci[i] = ((plaintext[i] + a) % 26) + 65;
            }

            else if (islower(plaintext[i]) && (isalpha(plaintext[i])))   //plaintext is upper
            {
                plaintext[i] = plaintext[i] - 97;
                ci[i] = ((plaintext[i] + a) % 26) + 97;
            }
            else 
            {
                ci[i] = plaintext[i];
            }

        }
        printf("ciphertext: ");
        for (int x = 0; x < n; x++)   //ciphertext output
        {
            printf("%c", ci[x]);
        }
        printf("\n");
    }

    
    else
    {
        printf("./caesar key\n ");
        return 1;
    }

}