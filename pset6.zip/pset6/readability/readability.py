from cs50 import get_string

t = get_string("Text: ")

l = 0   # l for letters

w = 0   # w for words

s = 0   # s for senc

for c in t:
    if (not(c.isspace())) and (c.isalpha()):    # count letters without spaces
        l += 1

    if c == "!" or c == "." or c == "?":
        s += 1

w = len(t.split())

l = l * 100 / w
s = s * 100 / w

x = round(0.0588 * l - 0.296 * s - 15.8)
print(x)
if x > 16:
    print("Grade 16+")

elif x < 1:
    print("Before Grade 1")

else:
    print(f"Grade {int(x)}")


# print(l)
# print(w)
# print(s)
