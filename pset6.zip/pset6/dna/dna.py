# Steps:
# 1: open CSV file and read data from
# 2: sotre data in CSV file in list which frist row (rows[0]) is Name and STRs
# 3: open txt file and read data from
# 4: search in txt for STRs and Return the no. of STR
# 5: compare the return STR with data in CSV file and rutern name if matched or No Match


from sys import argv, exit
import csv


def main():

    if len(argv) == 3:  # check argv is 3? name file + csv + txt
        # print(argv[1])
        # 1:
        with open(argv[1], "r") as csvf:
            readcsv = csv.reader(csvf)

            # headings = next(readcsv)
            # print(headings[1])
            # first_line = next(readcsv)
            # print(first_line)

            # 2:
            # row: is one line ic CSV file
            # rows: All line in CSV file which rows[1][2] is the the 3ed element in 2nd row
            rows = []
            for row in readcsv:
                #  print(row)
                rows.append(row)

            # print(rows[0][0])
            # print(len(row))
            # print(rows[0][1])

                # if row["name"] == "Bob":
                # print("bob")
            # 3:
            with open(argv[2], "r") as txtf:
                # print(argv[2])
                readtxt = txtf.read()

            # 4:
                strs = []   # each STRs in text file

                for a in range(len(row) - 1):   # for get STRs in CSV
                    # print(rows[0][a + 1])
                    n = readtxt.count(rows[0][a + 1])   # n is STR in "all" string
                    # print(n)

                    x = readtxt.count(rows[0][a + 1] * n)
                    while x < 1:
                        n -= 1
                        x = readtxt.count(rows[0][a + 1] * n)

                    strs.append(f"{n}")
                # print(f"{strs}")

            # 5:
            # print(len(rows))
            # print(len(row))
            # print(rows)
            for q in range(len(rows) - 1):
                # print(rows[q + 1][1 : len(rows)])
                # print(strs[0 : len(strs)])
                # print((strs[0 : len(strs)]))
                # print((rows[q + 1][1 : len(rows)]))
                # print(f"{strs[0 : len(strs)]}")
                # print((rows[q + 1][1 : len(rows)]) == (strs[0 : len(strs)]))
                if ((rows[q + 1][1: len(rows)]) == (strs[0: len(strs)])):
                    # print(rows[q])
                    print(rows[q + 1][0])
                    exit(0)

        print("No match")
        exit(1)

    else:
        print("Usage: python dna.py data.csv sequence.txt")
        exit(1)


main()