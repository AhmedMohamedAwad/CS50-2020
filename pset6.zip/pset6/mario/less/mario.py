from cs50 import get_int
from sys import exit

while True:
    i = get_int("Height: ")

    if i < 9 and i > 0:
        x = i
        for a in range(x):
            print(" " * (x - 1), end="")
            print("#" * (a + 1), end="\n")
            x -= 1

        break
        exit(0)
    else:
        print("Enter Number from 1 to 8 only")

