from cs50 import get_string

s = get_string("What is your name?\n")

print(f"hello, {s}")