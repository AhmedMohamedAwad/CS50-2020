from cs50 import get_float
from sys import exit

while True:
    i = get_float("Change owed: ")

    if i > 0:
        c = int(0)
        x = i
        x = int(i * 100)
        # print(x)
        if x >= 25:
            c = int(x / 25)
            x %= 25

        if x >= 10:
            c += int(x / 10)
            x %= 10

        if x >= 5:
            c += int(x / 5)
            x %= 5

        if x > 0:
            c += x

        print(int(c))
        exit(0)

    else:
        print("Enter Intger Num > 0")
