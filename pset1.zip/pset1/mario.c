#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int x = 0;
    while (x > 8 || x < 1)
    {
        x = get_int("Hight: ");
       
    }

    for (int j = 1; j <= x; j++)
    {
        for (int a = x - j; a > 0; a--)
        {
            printf(" ");
        }
        for (int i = 0; i < j; i++)
        {
            printf("#");
        }
        printf("\n");
          
    }
}
