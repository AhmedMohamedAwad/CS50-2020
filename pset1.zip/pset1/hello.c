#include <stdio.h>
#include <cs50.h>

int main(void)
{

    printf("hello, %s\n", get_string("What's Ur Name?"));
}
