#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
    int y; // is count of out
    float x = get_float("Change owed: ");
    if (x < 0)
    {
        x = get_float("Change owed: ");
    }
    else
    {
        int i = round(x * 100);
        y = i / 25;
        //printf("%i\n",y);
        int r = i % 25;
        //printf("%i %i\n",r,y);
        y = y + (r / 10);
        r = r % 10;
        //printf("%i %i\n",r,y);
        y = y + (r / 5);
        r = r % 5;
        y = y + (r / 1);
        printf("%i\n", y);

    }
}
