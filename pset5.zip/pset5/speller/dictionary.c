// Implements a dictionary's functionality

#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include<stdio.h>
#include <ctype.h>


#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

char w [LENGTH + 1];    //to store each string in dictionary
unsigned int count = 0;              //size count
FILE *d = NULL;               // point to dic file

// Number of buckets in hash table
const unsigned int N = 26;

// Hash table
node *table[N];

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    int ix;                 // ix: index hash a = 0, b = 1...etc.
    if (isupper(word[0]))
    {
        ix = (word[0] + 32) - 97;
    }

    else
    {
        ix = word[0] - 97;
    }

    node *temp = table[ix];
    while ((temp != NULL))
    {
        if (!strcasecmp(temp -> word, word))
        {
            return true;
        }
        temp = temp -> next;
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    node *n = malloc(sizeof(node));
    if (n == NULL)
    {
        return false;
    }
    else
    {
        strcpy(n -> word, w);
        n -> next = NULL;
        int ix = word[0] - 97;       // ix: index hash a = 0, b = 1...etc.
        //printf("%i\n%s\n%s\n",ix,w,word);

        if (table[ix] == NULL)
        {
            table[ix] = n;
        }
        else
        {
            n -> next = table[ix];
            table[ix] = n;
        }

        //printf("%i\n",ix);
        return ix;

    }
    return 0;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    d = fopen(dictionary, "r");   //pointer to read dictionary
    if (d == NULL)
    {
        return false;
    }
    else
    {
        for (int i = 0; i < 26; i++)
        {
            table[i] = NULL;
        }

        while (fscanf(d, "%s", w) != EOF)
        {
            hash(w);
            //printf("%i\n",hash(w));

            count ++;         // count no. of words in dic
        }

        fclose(d);
        return true;
    }
    fclose(d);
    return false;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    if (count == 0)
    {
        return 0;       //if not loaded Dictionary
    }
    else
    {
        return count;
    }
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    node *c = NULL;
    node *t = NULL;

    for (int i = 0; i < 26; i++)
    {
        if (table[i] != NULL)
        {
            c = table[i];
            t = c;

            while (c -> next != NULL)
            {

                c = c -> next;
                free(t);
                t = c;
            }
            if (c -> next == NULL)
            {
                free(t);
            }

        }

    }
    return true;
}
